# -*- coding: utf-8 -*-
"""
Created on Tue Jan 05 09:50:51 2016

@author: paulinkenbrandt
"""

class WQP:
    
    @staticmethod
    def WQPimportRes(csv):
        '''
        Bring data from WQP site into a Pandas Dataframe for analysis
        '''
        
        # set data types
        Rdtypes = {"OrganizationIdentifier":np.str_, "OrganizationFormalName":np.str_, "ActivityIdentifier":np.str_, 
               "ActivityStartTime/Time":np.str_,
               "ActivityTypeCode":np.str_, "ActivityMediaName":np.str_, "ActivityMediaSubdivisionName":np.str_, 
               "ActivityStartDate":np.str_, "ActivityStartTime/Time":np.str_, "ActivityStartTime/TimeZoneCode":np.str_, 
               "ActivityEndDate":np.str_, "ActivityEndTime/Time":np.str_, "ActivityEndTime/TimeZoneCode":np.str_, 
               "ActivityDepthHeightMeasure/MeasureValue":np.float16, "ActivityDepthHeightMeasure/MeasureUnitCode":np.str_, 
               "ActivityDepthAltitudeReferencePointText":np.str_, "ActivityTopDepthHeightMeasure/MeasureValue":np.float16, 
               "ActivityTopDepthHeightMeasure/MeasureUnitCode":np.str_, 
               "ActivityBottomDepthHeightMeasure/MeasureValue":np.float16, 
               "ActivityBottomDepthHeightMeasure/MeasureUnitCode":np.str_, 
               "ProjectIdentifier":np.str_, "ActivityConductingOrganizationText":np.str_, 
               "MonitoringLocationIdentifier":np.str_, "ActivityCommentText":np.str_, 
               "SampleAquifer":np.str_, "HydrologicCondition":np.str_, "HydrologicEvent":np.str_, 
               "SampleCollectionMethod/MethodIdentifier":np.str_, "SampleCollectionMethod/MethodIdentifierContext":np.str_, 
               "SampleCollectionMethod/MethodName":np.str_, "SampleCollectionEquipmentName":np.str_, 
               "ResultDetectionConditionText":np.str_, "CharacteristicName":np.str_, "ResultSampleFractionText":np.str_, 
               "ResultMeasureValue":np.str_, "ResultMeasure/MeasureUnitCode":np.str_, "MeasureQualifierCode":np.str_, 
               "ResultStatusIdentifier":np.str_, "StatisticalBaseCode":np.str_, "ResultValueTypeName":np.str_, 
               "ResultWeightBasisText":np.str_, "ResultTimeBasisText":np.str_, "ResultTemperatureBasisText":np.str_, 
               "ResultParticleSizeBasisText":np.str_, "PrecisionValue":np.str_, "ResultCommentText":np.str_, 
               "USGSPCode":np.str_, "ResultDepthHeightMeasure/MeasureValue":np.float16, 
               "ResultDepthHeightMeasure/MeasureUnitCode":np.str_, "ResultDepthAltitudeReferencePointText":np.str_, 
               "SubjectTaxonomicName":np.str_, "SampleTissueAnatomyName":np.str_, 
               "ResultAnalyticalMethod/MethodIdentifier":np.str_, "ResultAnalyticalMethod/MethodIdentifierContext":np.str_, 
               "ResultAnalyticalMethod/MethodName":np.str_, "MethodDescriptionText":np.str_, "LaboratoryName":np.str_, 
               "AnalysisStartDate":np.str_, "ResultLaboratoryCommentText":np.str_, 
               "DetectionQuantitationLimitTypeName":np.str_, "DetectionQuantitationLimitMeasure/MeasureValue":np.str_, 
               "DetectionQuantitationLimitMeasure/MeasureUnitCode":np.str_, "PreparationStartDate":np.str_, 
               "ProviderName":np.str_} 

        # define date field indices
        dt = [6,56,61]
        
        # read csv into DataFrame
        WQP = pd.read_csv(csv, dtype=Rdtypes, parse_dates=dt)
        
        # Map new names for columns
        ResFieldDict = {"AnalysisStartDate":"AnalysisDate", "ResultAnalyticalMethod/MethodIdentifier":"AnalytMeth", 
                "ResultAnalyticalMethod/MethodName":"AnalytMethId", "ResultDetectionConditionText":"DetectCond", 
                "ResultLaboratoryCommentText":"LabComments", "LaboratoryName":"LabName", 
                "DetectionQuantitationLimitTypeName":"LimitType", "DetectionQuantitationLimitMeasure/MeasureValue":"MDL", 
                "DetectionQuantitationLimitMeasure/MeasureUnitCode":"MDLUnit", "MethodDescriptionText":"MethodDescript", 
                "OrganizationIdentifier":"OrgId", "OrganizationFormalName":"OrgName", "CharacteristicName":"Param", 
                "ProjectIdentifier":"ProjectId", "MeasureQualifierCode":"QualCode", "ResultCommentText":"ResultComment", 
                "ResultStatusIdentifier":"ResultStatus", "ResultMeasureValue":"ResultValue", 
                "ActivityCommentText":"SampComment", "ActivityDepthHeightMeasure/MeasureValue":"SampDepth", 
                "ActivityDepthAltitudeReferencePointText":"SampDepthRef", 
                "ActivityDepthHeightMeasure/MeasureUnitCode":"SampDepthU", "SampleCollectionEquipmentName":"SampEquip", 
                "ResultSampleFractionText":"SampFrac", "ActivityStartDate":"SampleDate", "ActivityIdentifier":"SampleId", 
                "ActivityStartTime/Time":"SampleTime", "ActivityMediaSubdivisionName":"SampMedia", 
                "SampleCollectionMethod/MethodIdentifier":"SampMeth", "SampleCollectionMethod/MethodName":"SampMethName", 
                "ActivityTypeCode":"SampType", "MonitoringLocationIdentifier":"StationId", 
                "ResultMeasure/MeasureUnitCode":"Unit", "USGSPCode":"USGSPCode",
                "ActivityStartDate":"StartDate","ActivityStartTime/Time":"StartTime"} 
                
        # Rename Data
        WQP = WQP.rename(columns=ResFieldDict)
        
        def datetimefix(x,format):
            '''
            This script cleans date-time errors
            
            input
            x = date-time string
            format = format of date-time string
            
            output 
            formatted datetime type
            '''
            d = str(x[0]).lstrip().rstrip()[0:10]
            t = str(x[1]).lstrip().rstrip()[0:5].zfill(5)
            try:
                int(d[0:2])
            except(ValueError,TypeError,NameError):
                return np.nan
            try:
                int(t[0:2])
                int(t[3:5])
            except(ValueError,TypeError,NameError):
                t = "00:00"
           
            if int(t[0:2])>23:
                t = "00:00"
            elif int(t[3:5])>59:
                t = "00:00"
            else:
                t = t[0:2].zfill(2) + ":" + t[3:5]
            return datetime.datetime.strptime(d + " " + t, format)
        
        # Remove unwanted and bad times        
        WQP["SampleDate"] = WQP[["StartDate","StartTime"]].apply(lambda x: datetimefix(x,"%Y-%m-%d %H:%M"),1)
        
        # Define unneeded fields to drop
        resdroplist = ["ActivityBottomDepthHeightMeasure/MeasureUnitCode", "ActivityBottomDepthHeightMeasure/MeasureValue", 
               "ActivityConductingOrganizationText", "ActivityEndDate", "ActivityEndTime/Time", 
               "ActivityEndTime/TimeZoneCode", "ActivityMediaName", "ActivityStartTime/TimeZoneCode", 
               "ActivityTopDepthHeightMeasure/MeasureUnitCode", "ActivityTopDepthHeightMeasure/MeasureValue", 
               "HydrologicCondition", "HydrologicEvent", "PrecisionValue", "PreparationStartDate", "ProviderName", 
               "ResultAnalyticalMethod/MethodIdentifierContext", "ResultDepthAltitudeReferencePointText", 
               "ResultDepthHeightMeasure/MeasureUnitCode", "ResultDepthHeightMeasure/MeasureValue", 
               "ResultParticleSizeBasisText", "ResultTemperatureBasisText", 
               "ResultTimeBasisText", "ResultValueTypeName", "ResultWeightBasisText", "SampleAquifer", 
               "SampleCollectionMethod/MethodIdentifierContext", "SampleTissueAnatomyName", "StatisticalBaseCode", 
               "SubjectTaxonomicName","StartTime","StartDate","StartTime","StartDate"] 
        
        # Drop fields
        WQP = WQP.drop(resdroplist, axis=1)
        
        # convert results and mdl to float
        WQP['ResultValue'] = pd.to_numeric(WQP['ResultValue'])
        WQP['MDL'] = pd.to_numeric(WQP['MDL'])
        
        # match old and new station ids
        WQP['StationId'] = WQP['StationId'].str.replace('_WQX-','-')
                
        #standardize all ug/l data to mg/l
        def unitfix(x):
            z = str(x).lower()
            if z == "ug/l":
                return "mg/l"
            elif z == "mg/l":
                return "mg/l"
            else:
                return x
        
        WQP.Unit = WQP.Unit.apply(lambda x: str(x).rstrip(), 1)
        WQP.ResultValue = WQP[["ResultValue","Unit"]].apply(lambda x: x[0]/1000 if str(x[1]).lower()=="ug/l" else x[0], 1)
        WQP.Unit = WQP.Unit.apply(lambda x: unitfix(x),1)
        
        def parnorm(x):
            p = str(x[0]).rstrip().lstrip().lower()
            u = str(x[2]).rstrip().lstrip().lower()
            if p == 'nitrate' and u == 'mg/l as n':
                return 'Nitrate', x[1]*4.427, 'mg/l'
            elif p == 'nitrite' and u == 'mg/l as n':
                return 'Nitrite', x[1]*3.285, 'mg/l'
            elif p == 'ammonia-nitrogen' or p == 'ammonia-nitrogen as n' or p == 'ammonia and ammonium':
                return 'Ammonium', x[1]*1.288, 'mg/l'
            elif p == 'ammonium' and u == 'mg/l as n':
                return 'Ammonium', x[1]*1.288, 'mg/l'
            elif p == 'sulfate as s':
                return 'Sulfate', x[1]*2.996, 'mg/l'
            elif p in ('phosphate-phosphorus', 'phosphate-phosphorus as p','orthophosphate as p'):
                return 'Phosphate', x[1]*3.066, 'mg/l'
            elif (p == 'phosphate' or p == 'orthophosphate') and u == 'mg/l as p':
                return 'Phosphate', x[1]*3.066, 'mg/l'
            elif u == 'ug/l':
                return x[0], x[1]/1000, 'mg/l'
            else:
                return x[0], x[1], str(x[2]).rstrip()

        WQP['Param'], WQP['ResultValue'], WQP['Unit'] = zip(*WQP[['Param','ResultValue','Unit']].apply(lambda x: parnorm(x),1))
        
        return WQP
        
        
        