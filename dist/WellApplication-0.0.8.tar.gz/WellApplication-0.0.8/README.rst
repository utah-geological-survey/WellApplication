================
Well Application
================

Uses
====

This package:

* allows a user to upload data from an .xle file common with some water well transducers.

* matches well and barometric data to same sample intervals

* adjust with manual measurements

* removes skips and jumps from data

Modules
=======

transport
---------

This class has functions used to import transducer data and condition it for analysis.

